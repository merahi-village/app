# 🌱 Merahi Green

Android-first mobile app for **Merahi Village**: खेती, मौसम, Go Green और village information.

## Data sources
- Merahi Village: https://merahi-village.github.io
- Weather: Open-Meteo for Merahi
- Blog: https://merahivillage.blogspot.com

## Run
npm install
npm run dev

## Android build
npm install
npm run build
npx cap add android
npx cap sync android
cd android && ./gradlew assembleDebug

APK: android/app/build/outputs/apk/debug/app-debug.apk

Package: com.merahi.green
